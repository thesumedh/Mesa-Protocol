import { Mesa } from '@mesaprotocol/sdk';
export const flow = Mesa.flow('Cross-Border Remittance Corridor', 'cross-border-remittance-corridor').build();