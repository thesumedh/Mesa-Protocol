#![no_std]
use soroban_sdk::{contract, contractimpl, Symbol, Env};

#[contract]
pub struct VaultContract;

#[contractimpl]
impl VaultContract {
    pub fn deposit(env: Env, amount: i128) -> Symbol {
        Symbol::new(&env, "DEPOSITED")
    }
}
