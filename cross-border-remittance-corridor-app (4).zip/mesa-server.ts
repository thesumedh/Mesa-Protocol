import 'dotenv/config';
import express from 'express';
import { createServer } from '@mesaprotocol/runtime';
import { main as registerAndRun } from './packages/workflows/mesa.flow';

const app = createServer();
const port = process.env.PORT || 3001;

app.listen(port, async () => {
  console.log(`🚀 Mesa Production Runtime Server running on http://localhost:${port}`);
  try {
    await registerAndRun();
  } catch (err) {
    console.error('Failed to auto-register flow:', err);
  }
});
